import "./App.css";
import ListingContainer from "./ListingContainer";

function App() {
  return (
    <>
      <h1>Resorts Lite</h1>
      <ListingContainer />
    </>
  );
}

export default App;
